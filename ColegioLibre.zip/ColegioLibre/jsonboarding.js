(() => {
  "use strict";

  const SEARCH_DELAY_MS = 320;
  const MIN_SEARCH_LENGTH = 2;
  const MAX_RESULTS = 18;

  let selectedOnboardingSchool = null;
  let onboardingUser = null;
  let searchTimer = null;
  let searchRequestId = 0;
  let eventsBound = false;

  const byId = (id) => document.getElementById(id);

  async function initOnboarding() {
    const client = window.colegioLibreSupabase;

    if (!client) {
      console.error("No se encontró el cliente de Supabase.");
      return;
    }

    const { data, error: userError } = await client.auth.getUser();
    const user = data?.user || null;

    if (userError) {
      console.error("No se pudo comprobar la sesión:", userError);
      return;
    }

    if (!user) return;

    const { data: profile, error: profileError } = await client
      .from("profiles")
      .select("id, name, school_code")
      .eq("id", user.id)
      .maybeSingle();

    if (profileError) {
      console.error("No se pudo comprobar el perfil:", profileError);
      return;
    }

    if (profile?.school_code) return;

    onboardingUser = user;
    bindOnboardingEvents();

    const nameInput = byId("onboarding-name");
    if (nameInput && !nameInput.value && profile?.name) {
      nameInput.value = profile.name;
    }

    byId("onboarding-modal").hidden = false;
    window.setTimeout(() => nameInput?.focus(), 40);
  }

  function bindOnboardingEvents() {
    if (eventsBound) return;

    const form = byId("onboarding-form");
    const openSearch = byId("open-school-search");
    const closeSearch = byId("close-school-search");
    const schoolInput = byId("school-search-input");
    const schoolModal = byId("school-modal");

    if (!form || !openSearch || !closeSearch || !schoolInput || !schoolModal) {
      console.error("Faltan elementos del onboarding en el HTML.");
      return;
    }

    eventsBound = true;

    openSearch.addEventListener("click", openSchoolSearch);
    closeSearch.addEventListener("click", closeSchoolSearch);

    schoolInput.addEventListener("input", () => {
      window.clearTimeout(searchTimer);
      searchTimer = window.setTimeout(
        () => searchSchools(schoolInput.value),
        SEARCH_DELAY_MS
      );
    });

    schoolInput.addEventListener("keydown", (event) => {
      if (event.key !== "ArrowDown") return;
      event.preventDefault();
      byId("school-results")?.querySelector(".school-result")?.focus();
    });

    schoolModal.addEventListener("click", (event) => {
      if (event.target === schoolModal) closeSchoolSearch();
    });

    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && !schoolModal.hidden) {
        closeSchoolSearch();
      }
    });

    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      await saveOnboardingProfile();
    });
  }

  function openSchoolSearch() {
    const schoolModal = byId("school-modal");
    const schoolInput = byId("school-search-input");

    schoolModal.hidden = false;
    schoolInput.value = selectedOnboardingSchool?.name || "";
    renderSearchHint(
      selectedOnboardingSchool
        ? "Podés elegir otro colegio o volver."
        : "Buscá por nombre, siglas o dirección. También podés agregar la localidad."
    );

    window.setTimeout(() => {
      schoolInput.focus();
      schoolInput.select();
    }, 40);
  }

  function closeSchoolSearch() {
    byId("school-modal").hidden = true;
    searchRequestId += 1;
    window.clearTimeout(searchTimer);
  }

  async function searchSchools(rawQuery) {
    const query = String(rawQuery || "").trim();
    const requestId = ++searchRequestId;

    if (query.length < MIN_SEARCH_LENGTH) {
      renderSearchHint("Escribí al menos 2 letras para buscar.");
      return;
    }

    setSchoolSearchState("loading", "Buscando en el padrón oficial…");

    const { data, error } = await window.colegioLibreSupabase.rpc(
      "search_schools",
      {
        p_query: query,
        p_limit: MAX_RESULTS
      }
    );

    if (requestId !== searchRequestId) return;

    if (error) {
      console.error("No se pudieron buscar colegios:", error);
      setSchoolSearchState(
        "error",
        "No pudimos buscar colegios en este momento. Probá nuevamente."
      );
      return;
    }

    renderSchoolResults(Array.isArray(data) ? data : []);
  }

  function renderSchoolResults(schools) {
    const results = byId("school-results");
    results.replaceChildren();

    if (!schools.length) {
      setSchoolSearchState(
        "empty",
        "No lo encontramos con ese nombre. Probá con la dirección del colegio y su localidad."
      );
      return;
    }

    const fragment = document.createDocumentFragment();

    schools.forEach((school) => {
      const button = document.createElement("button");
      const title = document.createElement("strong");
      const location = document.createElement("span");
      const details = document.createElement("small");

      button.className = "school-result";
      button.type = "button";
      button.dataset.schoolId = school.school_id || "";

      title.textContent = school.name || "Colegio sin nombre";
      location.textContent = formatSchoolLocation(school);
      details.textContent = formatSchoolDetails(school);

      button.append(title, location, details);
      button.addEventListener("click", () => selectSchool(school));
      fragment.append(button);
    });

    results.append(fragment);
  }

  function selectSchool(school) {
    selectedOnboardingSchool = {
      id: school.school_id || school.id,
      code: school.code,
      cue: school.cue || null,
      name: school.name,
      province: school.province || "",
      city: school.city || "",
      zone_code: school.zone_code || school.city || school.province || "",
      address: school.address || "",
      education_levels: school.education_levels || []
    };

    const codeInput = byId("onboarding-school-code");
    if (codeInput) codeInput.value = selectedOnboardingSchool.code || "";

    updateSelectedSchoolPreview(selectedOnboardingSchool);
    setOnboardingMessage("", "");
    closeSchoolSearch();
  }

  async function saveOnboardingProfile() {
    const nameInput = byId("onboarding-name");
    const submitButton = byId("onboarding-submit");
    const name = String(nameInput?.value || "").trim();

    if (!onboardingUser) {
      setOnboardingMessage("Tu sesión venció. Volvé a iniciar sesión.", "error");
      return;
    }

    if (name.length < 2) {
      setOnboardingMessage("Ingresá tu nombre.", "error");
      nameInput?.focus();
      return;
    }

    if (!selectedOnboardingSchool?.id || !selectedOnboardingSchool?.code) {
      setOnboardingMessage("Buscá y seleccioná tu colegio.", "error");
      openSchoolSearch();
      return;
    }

    setSubmitBusy(submitButton, true);
    setOnboardingMessage("Verificando colegio…", "loading");

    const { data: school, error: schoolError } =
      await window.colegioLibreSupabase
        .from("schools")
        .select(
          "id, code, cue, name, display_name, community_code, province, city, zone_code, address, is_active"
        )
        .eq("id", selectedOnboardingSchool.id)
        .eq("is_active", true)
        .maybeSingle();

    if (schoolError || !school) {
      console.error("No se pudo verificar el colegio:", schoolError);
      selectedOnboardingSchool = null;
      updateSelectedSchoolPreview(null);
      setSubmitBusy(submitButton, false);
      setOnboardingMessage(
        "Ese colegio ya no está disponible. Seleccioná otro.",
        "error"
      );
      return;
    }

    setOnboardingMessage("Guardando tu perfil…", "loading");

    const profile = {
      id: onboardingUser.id,
      name,
      school_code: school.community_code || school.code,
      school_name: school.display_name || school.name,
      zone_code: school.zone_code || school.city || school.province || null
    };

    const { error: saveError } = await window.colegioLibreSupabase
      .from("profiles")
      .upsert(profile, { onConflict: "id" });

    if (saveError) {
      console.error("No se pudo guardar el perfil:", saveError);
      setSubmitBusy(submitButton, false);
      setOnboardingMessage(
        "No se pudo guardar tu perfil. Probá nuevamente.",
        "error"
      );
      return;
    }

    setOnboardingMessage("¡Listo! Ya configuramos tu colegio.", "success");
    window.setTimeout(() => window.location.reload(), 500);
  }

  function updateSelectedSchoolPreview(school) {
    const preview = byId("selected-school-preview");
    const button = byId("open-school-search");
    const buttonText = byId("school-picker-text");

    if (!school) {
      preview.hidden = true;
      preview.replaceChildren();
      button?.classList.remove("has-selection");
      if (buttonText) buttonText.textContent = "Buscar y seleccionar mi colegio";
      return;
    }

    const name = document.createElement("strong");
    const location = document.createElement("span");

    name.textContent = school.name;
    location.textContent = formatSchoolLocation(school);

    preview.replaceChildren(name, location);
    preview.hidden = false;
    button?.classList.add("has-selection");
    if (buttonText) buttonText.textContent = "Cambiar colegio";
  }

  function renderSearchHint(text) {
    setSchoolSearchState("hint", text);
  }

  function setSchoolSearchState(kind, text) {
    const results = byId("school-results");
    const message = document.createElement("p");

    message.className = `school-empty school-empty--${kind}`;
    message.textContent = text;
    results.replaceChildren(message);
  }

  function setOnboardingMessage(text, kind) {
    const message = byId("onboarding-message");
    message.textContent = text;
    message.dataset.state = kind || "";
  }

  function setSubmitBusy(button, isBusy) {
    if (!button) return;
    button.disabled = isBusy;
    button.textContent = isBusy ? "Guardando…" : "Continuar";
  }

  function formatSchoolLocation(school) {
    const values = [school.city, school.province]
      .map((value) => String(value || "").trim())
      .filter(Boolean);

    return [...new Set(values)].join(" · ") || "Argentina";
  }

  function formatSchoolDetails(school) {
    const address = String(school.address || "").trim();
    const levels = Array.isArray(school.education_levels)
      ? school.education_levels.join(" y ")
      : "";
    const code = school.code ? `Código ${school.code}` : "";
    return [address, levels, code].filter(Boolean).join(" · ");
  }

  window.initOnboarding = initOnboarding;
})();
