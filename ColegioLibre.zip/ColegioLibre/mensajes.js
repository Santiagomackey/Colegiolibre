(function () {

const {
  FALLBACK_PRODUCT_IMAGE,
  escapeHtml,
  formatDateTime,
  formatPrice,
  formatRelativeDate,
  getCurrentUser,
  getInitials,
  getStatusLabel,
  safeProductRecord
} = window.colegioLibreApi;

const requestedConversationId = new URLSearchParams(window.location.search).get("id");

const elements = {
  accountLink: document.getElementById("messages-account-link"),
  chatAvatar: document.getElementById("chat-avatar"),
  chatSubtitle: document.getElementById("chat-subtitle"),
  chatTitle: document.getElementById("chat-title"),
  conversationList: document.getElementById("conversation-list"),
  conversationSearch: document.getElementById("conversation-search"),
  globalSearchForm: document.getElementById("global-search-form"),
  globalSearchInput: document.getElementById("global-search-input"),
  messageForm: document.getElementById("message-form"),
  messageInput: document.getElementById("message-input"),
  messagesList: document.getElementById("messages-list"),
  mobileBackButton: document.getElementById("mobile-back-button"),
  productPanel: document.getElementById("product-panel"),
  sendButton: document.querySelector("#message-form button"),
  toast: document.getElementById("messages-toast")
};

const state = {
  activeConversationId: null,
  activeMessages: [],
  conversations: [],
  currentUser: null,
  realtimeChannel: null,
  searchTerm: ""
};

initMessagesPage();

async function initMessagesPage() {
  bindEvents();

  state.currentUser = await getCurrentUser();

  if (!state.currentUser) {
    window.location.href = "login.html";
    return;
  }

  if (elements.accountLink) {
    elements.accountLink.href = "perfil.html";
  }

  await refreshConversations({ preserveSelection: false });

  if (requestedConversationId) {
    await openConversation(requestedConversationId, { pushHistory: false });
  } else {
    renderConversationList();
    renderEmptyChat();
  }

  subscribeRealtime();
}

function bindEvents() {
  elements.globalSearchForm?.addEventListener("submit", (event) => {
    event.preventDefault();
    const term = elements.globalSearchInput?.value.trim();
    const url = term ? `index.html?search=${encodeURIComponent(term)}` : "index.html";
    window.location.href = url;
  });

  elements.conversationSearch?.addEventListener("input", (event) => {
    state.searchTerm = event.currentTarget.value.trim();
    renderConversationList();
  });

  elements.messageForm?.addEventListener("submit", handleSendMessage);
  elements.mobileBackButton?.addEventListener("click", () => {
    document.body.dataset.view = "list";
  });
}

async function refreshConversations({ preserveSelection = true } = {}) {
  const { data, error } = await window.colegioLibreSupabase
    .from("conversations")
    .select("*")
    .not("seller_id", "is", null)
    .or(`buyer_id.eq.${state.currentUser.id},seller_id.eq.${state.currentUser.id}`)
    .order("created_at", { ascending: false });

  if (error) {
    console.error("Error cargando conversaciones:", error);
    state.conversations = [];
    renderConversationList();
    if (!preserveSelection) {
      renderEmptyChat("No se pudieron cargar tus conversaciones.");
    }
    return;
  }

  const uniqueRows = dedupeConversations(data || []);

  if (!uniqueRows.length) {
    state.conversations = [];
    state.activeConversationId = null;
    renderConversationList();
    renderEmptyChat("Todavía no tenés conversaciones activas.");
    renderProductPlaceholder();
    setComposerEnabled(false);
    return;
  }

  const relatedData = await loadConversationRelations(uniqueRows);
  state.conversations = relatedData;

  if (preserveSelection && state.activeConversationId) {
    const exists = state.conversations.some((conversation) => conversation.id === state.activeConversationId);
    if (!exists) {
      state.activeConversationId = null;
      renderEmptyChat();
      renderProductPlaceholder();
      setComposerEnabled(false);
    }
  }

  renderConversationList();
}

function dedupeConversations(rows) {
  const registry = new Map();

  rows
    .filter((row) => row.product_id && row.buyer_id && row.seller_id)
    .forEach((row) => {
      const key = [row.product_id, row.buyer_id, row.seller_id].join("|");
      const previous = registry.get(key);
      const rowTime = getConversationSortTime(row);
      const previousTime = previous ? getConversationSortTime(previous) : 0;

      if (!previous || rowTime >= previousTime) {
        registry.set(key, row);
      }
    });

  return Array.from(registry.values());
}

function getConversationSortTime(conversation) {
  return new Date(
    conversation.last_message_at ||
      conversation.updated_at ||
      conversation.created_at ||
      Date.now()
  ).getTime();
}

async function loadConversationRelations(rows) {
  const otherUserIds = [];
  const productIds = [];

  rows.forEach((row) => {
    const otherId = getOtherUserId(row);
    if (otherId) otherUserIds.push(otherId);
    if (row.product_id) productIds.push(row.product_id);
  });

  const uniqueUserIds = Array.from(new Set(otherUserIds));
  const uniqueProductIds = Array.from(new Set(productIds));
  const uniqueConversationIds = rows.map((row) => row.id);

  const [{ data: profilesData }, { data: productsData }, { data: lastMessagesData }] = await Promise.all([
    uniqueUserIds.length
      ? window.colegioLibreSupabase
          .from("profiles")
          .select("id, name, school_name, zone_code")
          .in("id", uniqueUserIds)
      : Promise.resolve({ data: [] }),
    uniqueProductIds.length
      ? window.colegioLibreSupabase.from("products").select("*").in("id", uniqueProductIds)
      : Promise.resolve({ data: [] }),
    uniqueConversationIds.length
      ? window.colegioLibreSupabase
          .from("messages")
          .select("id, conversation_id, body, created_at, sender_id")
          .in("conversation_id", uniqueConversationIds)
          .order("created_at", { ascending: false })
      : Promise.resolve({ data: [] })
  ]);

  const profilesById = new Map((profilesData || []).map((profile) => [profile.id, profile]));
  const productsById = new Map((productsData || []).map((product) => [product.id, safeProductRecord(product)]));
  const lastMessageByConversation = new Map();

  (lastMessagesData || []).forEach((message) => {
    if (!lastMessageByConversation.has(message.conversation_id)) {
      lastMessageByConversation.set(message.conversation_id, message);
    }
  });

  return rows
    .map((row) => {
      const otherId = getOtherUserId(row);
      const otherProfile = otherId ? profilesById.get(otherId) || null : null;
      const product = productsById.get(row.product_id) || null;
      const lastMessage = lastMessageByConversation.get(row.id) || null;

      return {
        ...row,
        lastMessage,
        otherProfile,
        product,
        sortAt: lastMessage?.created_at || row.updated_at || row.created_at
      };
    })
    .filter((row) => row.seller_id)
    .sort((left, right) => new Date(right.sortAt || 0) - new Date(left.sortAt || 0));
}

function getOtherUserId(conversation) {
  return conversation.buyer_id === state.currentUser.id ? conversation.seller_id : conversation.buyer_id;
}

function getConversationName(conversation) {
  if (conversation.otherProfile?.name) {
    return conversation.otherProfile.name;
  }

  if (conversation.buyer_id === state.currentUser.id) {
    return conversation.product?.seller_name || "Vendedor";
  }

  return "Comprador";
}

function getConversationSchool(conversation) {
  return conversation.otherProfile?.school_name || conversation.product?.school_name || "Colegio no especificado";
}

function renderConversationList() {
  const query = normalize(state.searchTerm);
  const filtered = state.conversations.filter((conversation) => {
    const haystack = normalize(
      `${getConversationName(conversation)} ${getConversationSchool(conversation)} ${conversation.product?.title || ""} ${conversation.lastMessage?.body || ""}`
    );

    return !query || haystack.includes(query);
  });

  elements.conversationList.innerHTML = "";

  if (!filtered.length) {
    elements.conversationList.innerHTML = `
      <div class="conversation-empty">
        <strong>No hay conversaciones para mostrar.</strong>
        <span>Probá con otro término de búsqueda o iniciá una desde un producto.</span>
      </div>
    `;
    return;
  }

  filtered.forEach((conversation) => {
    const item = document.createElement("button");
    item.className =
      conversation.id === state.activeConversationId
        ? "conversation-item is-active"
        : "conversation-item";
    item.type = "button";
    item.innerHTML = `
      <div class="conversation-avatar">${escapeHtml(getInitials(getConversationName(conversation)))}</div>
      <div class="conversation-copy">
        <div class="conversation-row">
          <p class="conversation-title">${escapeHtml(getConversationName(conversation))}</p>
          <span class="conversation-time">${escapeHtml(formatConversationTime(conversation.lastMessage?.created_at || conversation.created_at))}</span>
        </div>
        <p class="conversation-school">${escapeHtml(getConversationSchool(conversation))}</p>
        <p class="conversation-product">${escapeHtml(conversation.product?.title || "Producto no disponible")}</p>
        <p class="conversation-last">${escapeHtml(conversation.lastMessage?.body || "Todavía no hay mensajes en esta conversación.")}</p>
      </div>
    `;

    item.addEventListener("click", () => {
      openConversation(conversation.id);
    });

    elements.conversationList.appendChild(item);
  });
}

async function openConversation(conversationId, { pushHistory = true } = {}) {
  if (!conversationId) return;

  let conversation = state.conversations.find((item) => item.id === conversationId);

  if (!conversation) {
    const { data, error } = await window.colegioLibreSupabase
      .from("conversations")
      .select("*")
      .eq("id", conversationId)
      .maybeSingle();

    if (error || !data) {
      console.error("Error cargando conversación puntual:", error);
      showToast("No se pudo abrir la conversación.");
      return;
    }

    if (data.buyer_id !== state.currentUser.id && data.seller_id !== state.currentUser.id) {
      showToast("No tenés acceso a esta conversación.");
      return;
    }

    const enriched = await loadConversationRelations([data]);
    conversation = enriched[0] || null;

    if (conversation) {
      state.conversations.unshift(conversation);
    }
  }

  if (!conversation) {
    showToast("No se encontró la conversación.");
    return;
  }

  state.activeConversationId = conversation.id;

  if (pushHistory) {
    history.replaceState(null, "", `mensajes.html?id=${encodeURIComponent(conversation.id)}`);
  }

  renderConversationList();
  renderConversationHeader(conversation);
  renderProductPanel(conversation);
  setComposerEnabled(true);
  document.body.dataset.view = "chat";
  await loadMessages(conversation.id);
}

function renderConversationHeader(conversation) {
  const name = getConversationName(conversation);
  const school = getConversationSchool(conversation);
  elements.chatAvatar.textContent = getInitials(name);
  elements.chatTitle.textContent = name;
  elements.chatSubtitle.textContent = school;
}

function renderProductPanel(conversation) {
  const product = conversation.product;

  if (!product) {
    renderProductPlaceholder("El producto asociado ya no está disponible.");
    return;
  }

  elements.productPanel.innerHTML = `
    <article class="product-card">
      <div class="product-card__media">
        <span class="product-card__status">${escapeHtml(getStatusLabel(product.status))}</span>
        <img src="${escapeHtml(product.image_url || FALLBACK_PRODUCT_IMAGE)}" alt="${escapeHtml(product.title)}" />
      </div>

      <div class="product-card__body">
        <h3>${escapeHtml(product.title)}</h3>
        <p class="product-card__price">${escapeHtml(formatPrice(product.price))}</p>

        <div class="product-card__meta">
          <p class="product-card__school">
            <svg class="icon"><use href="#icon-message"></use></svg>
            ${escapeHtml(product.school_name || "Colegio no especificado")}
          </p>
          <p class="product-card__location">
            <svg class="icon"><use href="#icon-pin"></use></svg>
            ${escapeHtml(product.location)}
          </p>
          <p class="product-card__location">
            <svg class="icon"><use href="#icon-clock"></use></svg>
            ${escapeHtml(formatRelativeDate(product.created_at))}
          </p>
        </div>

        <div class="product-card__actions">
          <a class="view-product-link" href="producto.html?id=${encodeURIComponent(product.id)}">
            <span>Ver producto</span>
            <svg class="icon"><use href="#icon-open"></use></svg>
          </a>
        </div>
      </div>
    </article>
  `;

  const image = elements.productPanel.querySelector("img");
  image.onerror = () => {
    image.src = FALLBACK_PRODUCT_IMAGE;
  };
}

function renderProductPlaceholder(message = "Cuando abras un chat, vas a ver acá el material asociado.") {
  elements.productPanel.innerHTML = `
    <div class="product-empty">
      <strong>Producto de la conversación</strong>
      <span>${escapeHtml(message)}</span>
    </div>
  `;
}

async function loadMessages(conversationId) {
  const { data, error } = await window.colegioLibreSupabase
    .from("messages")
    .select("*")
    .eq("conversation_id", conversationId)
    .order("created_at", { ascending: true });

  if (error) {
    console.error("Error cargando mensajes:", error);
    renderEmptyChat("No se pudieron cargar los mensajes.");
    return;
  }

  state.activeMessages = data || [];
  renderMessages();
}

function renderMessages() {
  elements.messagesList.innerHTML = "";

  if (!state.activeMessages.length) {
    elements.messagesList.innerHTML = `
      <div class="empty-chat">
        <strong>Todavía no hay mensajes.</strong>
        <span>Escribí el primero para abrir la conversación.</span>
      </div>
    `;
    return;
  }

  const stream = document.createElement("div");
  stream.className = "message-stream";

  state.activeMessages.forEach((message) => {
    const article = document.createElement("article");
    article.className =
      message.sender_id === state.currentUser.id ? "message is-mine" : "message";
    article.innerHTML = `
      <div class="message__body">${escapeHtml(message.body)}</div>
      <span class="message__time">${escapeHtml(formatDateTime(message.created_at))}</span>
    `;
    stream.appendChild(article);
  });

  elements.messagesList.appendChild(stream);
  elements.messagesList.scrollTop = elements.messagesList.scrollHeight;
}

function renderEmptyChat(message = "Elegí un chat de la izquierda para empezar.") {
  elements.chatAvatar.textContent = "?";
  elements.chatTitle.textContent = "Seleccioná una conversación";
  elements.chatSubtitle.textContent = "ColegioLibre";
  elements.messagesList.innerHTML = `
    <div class="empty-chat">
      <strong>No hay conversación abierta.</strong>
      <span>${escapeHtml(message)}</span>
    </div>
  `;
}

function setComposerEnabled(enabled) {
  elements.messageInput.disabled = !enabled;
  elements.sendButton.disabled = !enabled;

  if (!enabled) {
    elements.messageInput.value = "";
  }
}

async function handleSendMessage(event) {
  event.preventDefault();

  if (!state.activeConversationId) {
    showToast("Elegí una conversación antes de enviar.");
    return;
  }

  const body = elements.messageInput.value.trim();
  if (!body) return;

  const { error } = await window.colegioLibreSupabase.from("messages").insert({
    body,
    conversation_id: state.activeConversationId,
    sender_id: state.currentUser.id
  });

  if (error) {
    console.error("Error enviando mensaje:", error);
    showToast("No se pudo enviar el mensaje.");
    return;
  }

  elements.messageInput.value = "";
  await loadMessages(state.activeConversationId);
  await refreshConversations();
}

function subscribeRealtime() {
  if (state.realtimeChannel) {
    window.colegioLibreSupabase.removeChannel(state.realtimeChannel);
  }

  state.realtimeChannel = window.colegioLibreSupabase
    .channel(`colegiolibre-messages-${state.currentUser.id}`)
    .on(
      "postgres_changes",
      { event: "INSERT", schema: "public", table: "messages" },
      async (payload) => {
        const conversationId = payload.new?.conversation_id;
        if (!conversationId) return;

        const isKnownConversation = state.conversations.some((conversation) => conversation.id === conversationId);
        if (!isKnownConversation && conversationId !== state.activeConversationId) {
          return;
        }

        await refreshConversations();

        if (conversationId === state.activeConversationId) {
          await loadMessages(conversationId);
        }
      }
    )
    .on(
      "postgres_changes",
      { event: "INSERT", schema: "public", table: "conversations" },
      async (payload) => {
        const conversation = payload.new;
        if (!conversation?.seller_id) return;

        if (
          conversation.buyer_id === state.currentUser.id ||
          conversation.seller_id === state.currentUser.id
        ) {
          await refreshConversations();
        }
      }
    )
    .subscribe();
}

function normalize(value) {
  return String(value || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

function formatConversationTime(dateValue) {
  if (!dateValue) return "";

  const date = new Date(dateValue);
  const now = new Date();
  const isSameDay =
    date.getDate() === now.getDate() &&
    date.getMonth() === now.getMonth() &&
    date.getFullYear() === now.getFullYear();

  if (isSameDay) {
    return date.toLocaleTimeString("es-AR", {
      hour: "2-digit",
      minute: "2-digit"
    });
  }

  return date.toLocaleDateString("es-AR", {
    day: "2-digit",
    month: "2-digit"
  });
}

function showToast(message) {
  elements.toast.textContent = message;
  elements.toast.hidden = false;
  window.clearTimeout(showToast.timeoutId);
  showToast.timeoutId = window.setTimeout(() => {
    elements.toast.hidden = true;
  }, 2200);
}

})();
